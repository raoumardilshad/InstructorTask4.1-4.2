using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    private Rigidbody playerRb;
    private GameObject focalPoint;
    private float maxVelocity = 20.0f;
    //private float speed = 10.0f ;
    // Start is called before the first frame update
    void Start()
    {
        playerRb = GetComponent<Rigidbody>();
        focalPoint = GameObject.Find("FocalPoint");
    }

    // Update is called once per frame
    void Update()
    {
        applyForce(10);
        
    }
    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.CompareTag("Enemy"))
        {
        reverseForce(5);
        }
    }

    void applyForce(float bspeed)
    {
        float forwardInput = Input.GetAxis("Vertical");
        playerRb.AddForce(focalPoint.transform.forward * forwardInput * bspeed, ForceMode.Impulse);
    }

    void reverseForce(float rspeed)
    {
        playerRb.AddForce(focalPoint.transform.forward * rspeed, ForceMode.VelocityChange);
        //playerRb.velocity = Vector3.ClampMagnitude(playerRb.velocity, maxVelocity);
    }
}
