using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : MonoBehaviour
{
    public float speed = 3.0f;
    private Rigidbody enemyRb;
    private GameObject players;
    // Start is called before the first frame update
    void Start()
    {
        enemyRb = GetComponent<Rigidbody>();
        players = GameObject.Find("Player");
        
    }

    // Update is called once per frame
    void Update()
    {
        ApplyForce(3);
        if (transform.position.y < -3)
        {
            Destroy(gameObject);
            players.transform.transform.localScale += transform.localScale;
        }
    }

    private void OnCollisionEnter(Collision collision)
    {
        ApplyForce(50);
    }
    void ApplyForce(float Espeed)
    {
        Vector3 lookDirection = (players.transform.position - transform.position).normalized;
        enemyRb.AddForce(lookDirection * Espeed, ForceMode.Force);
    }
}
